# IDRBT - Cloud Retrieval
# Webpage: https://www.idrbt.ac.in
# Contact: hussainsajid@acm.org
# Institute of Development and Research in Banking Technology
# 
# The Original Code is q_vector.py
# This program generates the query vector from the given keywords. The keywords are stored as a list 
# in a json file named given as argument
#
# 
# Running : $ 
# Output :
#
# Contributor(s):
#  Sajid Hussain

import os, zipfile
import json, nltk

from ctypes import *

def gen_query(qlist):
	#pattern = r'''(?x)
	#	([A-Z]\.)+
	#		| \w+(-\w+)*
	#		| \$?\d+(\.\d+)?%? 
	#		| \.\.\.
	#		| [][.,;"'?():-_`] 
	#	'''
	pattern = r'''(?x)
		(?:[A-Z]\.)+        # abbreviations, e.g. U.S.A.
      		| \w+(?:-\w+)*        # words with optional internal hyphens
      		| \$?\d+(?:\.\d+)?%?  # currency and percentages, e.g. $12.40, 82%
      		| \.\.\.              # ellipsis
      		| [][.,;"'?():_`-]    # these are separate tokens; includes ], [
    	'''

	# tokens is a list containing all the words in the contents of the mail in list

	qlist = nltk.regexp_tokenize(qlist, pattern)
	qlist = [i.lower() for i in qlist]
	dict_file = open('dictionary.json', 'r')
	dict_list = json.load(dict_file)
	num_words_dict = len(dict_list)
	keyw_set = set(qlist)
	q_vec = []

	for word in dict_list:
		if word in keyw_set:
			q_vec.append(1)
		else:
			q_vec.append(0)
	

	current_path = os.getcwd()
	current_path = current_path[:-7]
	print current_path
	os.environ["LD_LIBRARY_PATH"] = os.path.join(current_path , "lib")

	#crypt_lib = CDLL("/home/swa/Downloads/cloud-IDRBT-master/Bank/PreProcessing/crypting_vector.so")
	crypt_lib = CDLL("crypting_vector.so")
	
	q_arr = (c_int * len(q_vec))(*q_vec)
	rand_seed = 4321
	print "here"
	print q_arr
	print c_int
	print c_int(num_words_dict)
	print c_int(rand_seed)
	crypt_lib.crypt_vector(q_arr, c_int(num_words_dict), c_int(1), c_int(rand_seed))
	print "here"
	crpzip = zipfile.ZipFile("query.zip", "w")
	crpzip.write(os.path.join("crypt_1.key"))
	crpzip.write(os.path.join("crypt_2.key"))
	crpzip.close()
	os.remove("crypt_1.key")
	os.remove("crypt_2.key")

